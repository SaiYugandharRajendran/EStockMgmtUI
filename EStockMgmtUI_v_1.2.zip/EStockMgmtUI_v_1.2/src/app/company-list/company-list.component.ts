import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Company } from '../company';
import { CompanyService } from '../company.service';
import { Sort } from '@angular/material/sort';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.css']
})
export class CompanyListComponent implements OnInit {
  private searchEventSubscription:Subscription |any;
  
  constructor(private companyService: CompanyService, private router:Router) { 
  }

  ngOnInit(): void {
    this.getAll();
  }

  companies:Array<Company> = [];
  data:{} |any;
  companyCode:number |any;
  sort:Sort |any;

  getAll(){
    this.companyService.getall().subscribe(data=>
      {
        console.log(Object.values(data));
        this.companies=Object.values(data);
      },
      error=>{
        console.log(error);
      })
  }

  delete(companyCode:number){
    this.companyService.delete(companyCode).subscribe(data=>
      {
        console.log("Record is deleted!",Object.values(data));
        let cIndex=this.companies.findIndex(c=>c.companyCode === companyCode);
        console.log(cIndex);
        this.companies.splice(cIndex,1);
        this.getAll();
      },
      error=>
      {
        console.log(error);
      })
  }

  searchCompany(companyCode:number){
    this.router.navigate(['search-company',companyCode]);
  }

  updateCompany(companyCode:number, companymod:Company){
    this.router.navigate(['update-company',companyCode]);
  }

  updatePost(companyCode:number,companymod:Company){
    this.router.navigate(['update-post',companyCode]);
  }

}
