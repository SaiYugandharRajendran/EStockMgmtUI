import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Company } from '../company';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-update-post',
  templateUrl: './update-post.component.html',
  styleUrls: ['./update-post.component.css']
})
export class UpdatePostComponent implements OnInit {

  companymod:Company = new Company();
  companyCode:number |any;
  data:{} |any;
  companies:Array<Company> = [];
  alert:boolean =false;

  constructor(private companyService:CompanyService, private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.companyCode = this.route.snapshot.params['companyCode'];
    this.companyService.getCompany(this.companyCode).subscribe(data=>
      {
        this.companymod=data;
      },
      error=>
      {
        console.log(error);
      })
  }

  updatePost(companyCode:number,companymod:Company){
    this.companyService.updatePut(companyCode,companymod).subscribe(data=>
      {
        this.data = JSON.stringify(data);
        this.companies.push(this.data);       
        this.alert=true; 
        alert("Stock Price updated successfully");
      },
      error=>
      {
        console.log(error);
      })
  }

}
