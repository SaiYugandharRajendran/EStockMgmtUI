import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Company } from '../company';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-search-company',
  templateUrl: './search-company.component.html',
  styleUrls: ['./search-company.component.css']
})
export class SearchCompanyComponent implements OnInit {

  companyCode:number |any;
  companymod:Company |any;

  constructor(private route:ActivatedRoute, private companyService:CompanyService) { }

  ngOnInit(): void {
    this.companyCode=this.route.snapshot.params['companyCode'];
    this.companyService.getCompany(this.companyCode).subscribe(data=>
      {
        this.companymod=data;
      },
      error=>
      {
        console.log(error);
      })
  }

}
