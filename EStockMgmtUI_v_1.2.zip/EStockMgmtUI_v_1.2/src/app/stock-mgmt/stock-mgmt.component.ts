import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Company } from '../company';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-stock-mgmt',
  templateUrl: './stock-mgmt.component.html',
  styleUrls: ['./stock-mgmt.component.css']
})
export class StockMgmtComponent implements OnInit {

  public sp:number=0;
  public average:number=0;
  public min:number=0;
  public max:number=0;
  companies:Array<Company> = [];
  data:{} |any;
  public tmp:number |any;
  public alert:boolean |any;
  public stockPrice:number |any;

  constructor(private companyService:CompanyService, private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.stockPrice=this.route.snapshot.params['stockPrice'];
    this.getAll();
  }

  getAll(){
    this.companyService.getall().subscribe(data=>
      {
        console.log(Object.values(data));
        this.companies=Object.values(data);
        this.sp = this.companies.reduce((acc,val)=>{
          return acc+val.stockPrice;
        },0)
        this.average=this.sp/this.companies.length;
        console.log(this.sp);

        this.min = Number.POSITIVE_INFINITY;
        this.max = Number.NEGATIVE_INFINITY;
        for(var i=0;i<this.companies.length;i++){
          this.tmp=this.companies[i].stockPrice;
          if(this.tmp>this.max){
            this.max = this.tmp;
          }          
          if(this.tmp<this.min){
            this.min=this.tmp;
          }          
        }
        console.log(this.average,this.min,this.max);
        if(this.average>this.stockPrice){
          this.alert=true;
        }

        
      },
      error=>{
        console.log(error);
      })
  }

}
